package Exercicio1;

public interface InterfaceGravador {
	public void gravarNoArquivo(Cliente cliente);
}
