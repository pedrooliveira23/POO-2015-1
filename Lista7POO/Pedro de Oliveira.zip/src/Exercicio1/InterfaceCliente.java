package Exercicio1;

public interface InterfaceCliente {
	public String getNome();
	public char getSexo();
	public int getDiaNascimento();
	public int getMesNascimento();
	public int getAnoNascimento();
	public int getIdade();
}
