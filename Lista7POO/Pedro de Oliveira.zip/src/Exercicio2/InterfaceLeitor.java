package Exercicio2;

import java.util.ArrayList;

public interface InterfaceLeitor {
	public ArrayList<Cliente> lerArquivos();

}
