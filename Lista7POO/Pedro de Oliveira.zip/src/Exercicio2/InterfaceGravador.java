package Exercicio2;

public interface InterfaceGravador {
	public void gravarNoArquivo(Cliente cliente);
}
