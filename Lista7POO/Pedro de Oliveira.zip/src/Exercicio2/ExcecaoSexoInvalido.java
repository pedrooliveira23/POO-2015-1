package Exercicio2;

public class ExcecaoSexoInvalido extends Exception {
	ExcecaoSexoInvalido() {
		super("Sexo inválido! Entre com M ou F");
	}
}
